package UTSwildan;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Menu Tampilkan Suara Hewan");
        System.out.println("1. Kucing");
        System.out.println("2. Sapi");
        System.out.println("3. Anjing");
        System.out.print("Masukkan Pilihan Anda: ");
        int Pilihan = input.nextInt();

        switch (Pilihan) {
            case 1:
                Kucing meong = new Kucing("Kubi");
                System.out.println("Kucingku Namanya " + meong.getNama());
                meong.Suara();
                break;
            case 2:
                Sapi emoo = new Sapi("milky");
                System.out.println("Sapiku Namanya " + emoo.getNama());
                emoo.Suara();
                break;
            case 3:
                Anjing gogog = new Anjing("dodo");
                System.out.println("Anjingku Namanya " + gogog.getNama());
                gogog.Suara();
                break;
            default:
                System.out.println("Pilihan Yang Anda Masukkan Salah!");
                break;
        }
    }
}
