package UTSwildan;

public class Kucing extends Animal {
    public Kucing(String nama) {
        super(nama);
    }

    @Override
    public void Suara() {
        System.out.println("Suaranya Meong");
    }
}
