package UTSwildan;

public class Anjing extends Animal {
    public Anjing(String nama) {
        super(nama);
    }

    @Override
    public void Suara() {
        System.out.println("Suaranya menggonggong");
    }
}
