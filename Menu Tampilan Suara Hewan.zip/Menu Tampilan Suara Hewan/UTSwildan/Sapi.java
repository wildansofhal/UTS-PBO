package UTSwildan;

public class Sapi extends Animal {
    public Sapi(String nama) {
        super(nama);
    }

    @Override
    public void Suara() {
        System.out.println("Suaranya Mooooo");
    }
}
