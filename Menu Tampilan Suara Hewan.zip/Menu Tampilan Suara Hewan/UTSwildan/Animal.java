package UTSwildan;

public class Animal {
    private String nama;

    public Animal(String nama) {
        this.nama = nama;
    }

    public String getNama() {
        return this.nama;
    }

    public void Suara() {
        System.out.println();
    }

}
